var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    /* Toggle between adding and removing the "active" class,
    to highlight the button that controls the panel */
    this.classList.toggle("active");

    /* Toggle between hiding and showing the active panel */
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
      
      
    } else {
      panel.style.display = "block";
    }
  });
}

var imageIndex = 0;
var images = ["./images/cleanwater.jpg", "./images/healthy food.png","./images/information.jpg","./images/wash hands.jpg","./images/water treatment.png"]; // Add your image paths here
var imageElement = document.getElementById("information");

function changeImage() {
  imageElement.style.opacity = 0; // Set opacity to 0 for a fade-out effect
  setTimeout(function() {
    imageElement.src = images[imageIndex];
    imageElement.style.opacity = 1; // Set opacity back to 1 for a fade-in effect
  }, 1000); // Change this timeout to match your transition duration
  imageIndex = (imageIndex + 1) % images.length;
}

setInterval(changeImage, 5000); // Change image every 4 seconds (including fade duration)


